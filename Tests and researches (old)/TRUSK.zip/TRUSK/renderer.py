import matplotlib.pyplot as plt


class Renderer:
    def __init__(self, width=10, height=10, target_fps=10):
        """A class that abstracts the rendering engine"""
        self.WIDTH = width
        self.HEIGHT = height
        self.TARGET_FPS = target_fps
        
        self.fig, self.axes = plt.subplots()
        self.axes.set_xlim(-200, self.WIDTH)
        self.axes.set_ylim(-200, self.HEIGHT)
        self.axes.set_axis_off()


    def draw(self):
        """Renders the scene."""
        plt.pause(1/self.TARGET_FPS)
        self.axes.cla()
        self.axes.set_xlim(-200, self.WIDTH)
        self.axes.set_ylim(-200, self.HEIGHT)
        self.axes.set_axis_off()


    def point(self, x, y, style = "k."):
        """Sets the point (x, y) to the character char."""
        self.axes.plot(x, y, style)


    def rect(self, x, y, w, h, style = "orange"):
        """Draws a rectangle whose top left corner is at (x, y) and of width w and height h."""
        ...


    def ellipse(self, x, y, w, h, char):
        """Draws an ellipse of center (x, y) and of width h and height h."""
        ...


    def line(self, x1, y1, x2, y2, width=1, style="k-"):
        """Draws a line between the two points (x1, y1) (x2, y2)."""
        self.axes.plot([x1, x2], [y1, y2], style, lw = width)
        

    def text(self, x, y, s):
        """Write the text s statring at the x, y location on the screen."""
        ...