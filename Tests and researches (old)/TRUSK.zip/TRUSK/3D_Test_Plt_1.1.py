import numpy as np
import matplotlib.pyplot as plt

fig, axes = plt.subplots()

t = 0
x = [0,0]
y = [0,0]
axes.set_xlim(-10, 10)
axes.set_ylim(-10, 10)
axes.axis("scaled")
axes.set_axis_off()

courbe, = axes.plot(x, y, "-b")
while True:
    plt.pause(0.1)
    t += 0.1
    x = [0, np.cos(t) * 5]
    y = [0, np.cos(t) * 5]
    courbe.set_xdata(x)
    courbe.set_ydata(y)
    
